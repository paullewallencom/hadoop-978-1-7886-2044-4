package com.packt.streaming;

public interface IIPScanner {

    boolean isFraudIP(String ipAddresses);

}
