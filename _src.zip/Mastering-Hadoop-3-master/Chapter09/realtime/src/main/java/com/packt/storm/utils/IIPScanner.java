package com.packt.storm.utils;

public interface IIPScanner {

    boolean isFraudIP(String ipAddresses);

}
